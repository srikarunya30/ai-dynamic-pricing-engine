"""
dynamic_pricing_engine.py
============================================================================
AI-Powered Dynamic Pricing Engine — SINGLE FILE EDITION

Everything is in this one file: synthetic dataset generation, data
preprocessing, feature engineering, multi-model demand prediction, price
optimization, competitor analysis, demand forecasting, anomaly detection,
SHAP explainability, SQLite persistence, and the full multi-page Streamlit
dashboard.

HOW TO RUN
----------
    pip install streamlit pandas numpy scikit-learn xgboost shap plotly joblib
    streamlit run dynamic_pricing_engine.py

On first run it will automatically generate the dataset and train the
models (takes ~15-30 seconds), then open the dashboard. On later runs it
reuses the saved dataset/model instantly. Everything it creates (dataset,
model, database) is stored next to this file in a folder called
`dpe_workspace/`, so the whole project really is this one .py file.
============================================================================
"""

import os
import sqlite3
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from contextlib import contextmanager

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, IsolationForest
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
import shap

# ============================================================================
# 1. CONFIG
# ============================================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WORK_DIR = os.path.join(BASE_DIR, "dpe_workspace")
DATA_DIR = os.path.join(WORK_DIR, "data")
MODELS_DIR = os.path.join(WORK_DIR, "models")
DB_PATH = os.path.join(WORK_DIR, "pricing.db")

PRODUCTS_CSV = os.path.join(DATA_DIR, "products.csv")
SALES_CSV = os.path.join(DATA_DIR, "sales.csv")
COMPETITORS_CSV = os.path.join(DATA_DIR, "competitors.csv")

DEMAND_MODEL_PATH = os.path.join(MODELS_DIR, "demand_model.pkl")
SCALER_PATH = os.path.join(MODELS_DIR, "scaler.pkl")
ENCODERS_PATH = os.path.join(MODELS_DIR, "encoders.pkl")
METRICS_PATH = os.path.join(MODELS_DIR, "model_metrics.pkl")
SAMPLE_PATH = os.path.join(MODELS_DIR, "train_sample.pkl")

NUM_TRANSACTIONS = 20000
NUM_PRODUCTS = 40
RANDOM_SEED = 42

CATEGORIES = ["Electronics", "Fashion", "Grocery", "Home & Kitchen",
              "Beauty", "Sports", "Books", "Toys"]
SEASONS = ["Spring", "Summer", "Autumn", "Winter"]
CUSTOMER_SEGMENTS = ["Budget", "Regular", "Premium"]
WEATHER_CONDITIONS = ["Sunny", "Rainy", "Cloudy", "Stormy", "Normal"]

DEFAULT_MIN_MARGIN_PCT = 8.0
DEFAULT_MAX_DISCOUNT_PCT = 40.0
DEFAULT_MIN_PRICE_MULTIPLIER = 0.6
DEFAULT_MAX_PRICE_MULTIPLIER = 1.6
CANDIDATE_PRICE_STEPS = 25

CRITICAL_INVENTORY_LEVEL = 15
LOW_INVENTORY_LEVEL = 50
HIGH_INVENTORY_LEVEL = 300

TEST_SIZE = 0.15
VAL_SIZE = 0.15
OPTIMIZATION_OBJECTIVES = ["Maximum Revenue", "Maximum Profit",
                            "Maximum Sales", "Inventory Clearance"]

CATEGORICAL_COLS = ["category", "day_of_week", "season",
                     "customer_segment", "weather_condition"]

MODEL_FEATURES = [
    "current_price", "competitor_price", "price_diff", "price_diff_pct",
    "discount_percentage", "price_to_cost_ratio",
    "inventory_level", "inventory_to_demand_ratio", "stock_pressure",
    "is_weekend", "is_holiday", "month", "quarter",
    "product_popularity", "customer_rating",
    "website_visits", "cart_additions", "conversion_rate",
    "promotion_active",
    "rolling_7d_demand", "rolling_30d_demand", "demand_growth_rate",
    "category_enc", "season_enc", "customer_segment_enc", "weather_condition_enc",
]
TARGET = "units_sold"

rng = np.random.default_rng(RANDOM_SEED)


# ============================================================================
# 2. SYNTHETIC DATASET GENERATION
# ============================================================================
def month_to_season(month):
    if month in (3, 4, 5):
        return "Spring"
    if month in (6, 7, 8):
        return "Summer"
    if month in (9, 10, 11):
        return "Autumn"
    return "Winter"


def generate_products(n=NUM_PRODUCTS):
    rows = []
    for pid in range(1, n + 1):
        category = rng.choice(CATEGORIES)
        base_cost = float(np.round(rng.uniform(80, 4000), 2))
        markup = rng.uniform(1.3, 2.2)
        original_price = round(base_cost * markup, 2)
        popularity = round(rng.beta(2, 2), 3)
        rating = round(rng.uniform(3.0, 5.0), 1)
        rows.append({
            "product_id": pid,
            "product_name": f"{category[:4].upper()}-{pid:03d}",
            "category": category,
            "supplier_cost": base_cost,
            "original_price": original_price,
            "product_popularity": popularity,
            "customer_rating": rating,
        })
    return pd.DataFrame(rows)


def generate_competitors(products_df, days=180):
    rows = []
    start = datetime.today() - timedelta(days=days)
    for _, prod in products_df.iterrows():
        base = prod["original_price"]
        drift = rng.normal(0, 0.002)
        level = base
        for d in range(days):
            date = start + timedelta(days=d)
            level = max(base * 0.5, level * (1 + drift + rng.normal(0, 0.01)))
            comp_a = level * rng.uniform(0.92, 1.05)
            comp_b = level * rng.uniform(0.90, 1.08)
            comp_c = level * rng.uniform(0.94, 1.10)
            rows.append({
                "product_id": prod["product_id"],
                "date": date.strftime("%Y-%m-%d"),
                "competitor_a_price": round(comp_a, 2),
                "competitor_b_price": round(comp_b, 2),
                "competitor_c_price": round(comp_c, 2),
            })
    return pd.DataFrame(rows)


def _recency_weights(days):
    w = np.linspace(0.6, 1.4, days)
    return w / w.sum()


def generate_sales(products_df, competitors_df, n=NUM_TRANSACTIONS, days=180):
    comp_lookup = competitors_df.set_index(["product_id", "date"])
    start = datetime.today() - timedelta(days=days)
    product_ids = products_df["product_id"].values

    inventory_state = {pid: int(rng.integers(150, 500)) for pid in product_ids}
    rows = []
    tx_id = 1
    day_offsets = rng.choice(np.arange(days), size=n, p=_recency_weights(days))
    day_offsets.sort()

    for offset in day_offsets:
        date = start + timedelta(days=int(offset))
        date_str = date.strftime("%Y-%m-%d")
        pid = int(rng.choice(product_ids))
        prod = products_df.loc[products_df.product_id == pid].iloc[0]

        try:
            comp_row = comp_lookup.loc[(pid, date_str)]
            competitor_price = float(np.mean([
                comp_row["competitor_a_price"], comp_row["competitor_b_price"],
                comp_row["competitor_c_price"],
            ]))
        except KeyError:
            competitor_price = prod["original_price"]

        season = month_to_season(date.month)
        day_of_week = date.strftime("%A")
        is_weekend = date.weekday() >= 5
        holiday = bool(rng.random() < 0.04)
        promotion_active = bool(rng.random() < 0.22)

        price_noise = rng.normal(1.0, 0.07)
        current_price = max(prod["supplier_cost"] * 1.05, competitor_price * price_noise)
        discount_pct = 0.0
        if promotion_active:
            discount_pct = round(rng.uniform(5, 35), 1)
            current_price = current_price * (1 - discount_pct / 100)
        current_price = round(current_price, 2)

        inventory_level = inventory_state[pid]
        reorder_level = 60

        price_ratio = current_price / prod["original_price"]
        elasticity = -1.6
        base_demand = 12 + 40 * prod["product_popularity"]

        season_multiplier = {"Winter": 1.15, "Summer": 0.95, "Spring": 1.0, "Autumn": 1.05}[season]
        weekend_multiplier = 1.25 if is_weekend else 1.0
        holiday_multiplier = 1.6 if holiday else 1.0
        promo_multiplier = 1.5 if promotion_active else 1.0
        rating_multiplier = 0.7 + (prod["customer_rating"] / 5.0) * 0.6

        price_effect = price_ratio ** elasticity
        inventory_pressure = 1.0 if inventory_level > reorder_level else 0.6

        expected_units = (base_demand * price_effect * season_multiplier *
                           weekend_multiplier * holiday_multiplier *
                           promo_multiplier * rating_multiplier * inventory_pressure)
        noise = rng.normal(1.0, 0.18)
        units_sold = max(0, int(round(expected_units * noise)))
        units_sold = min(units_sold, inventory_level)

        inventory_state[pid] = max(0, inventory_level - units_sold)
        if inventory_state[pid] < reorder_level and rng.random() < 0.3:
            inventory_state[pid] += int(rng.integers(150, 400))

        website_visits = int(max(units_sold * rng.uniform(8, 25), rng.integers(20, 400)))
        cart_additions = int(website_visits * rng.uniform(0.05, 0.25))
        conversion_rate = round(units_sold / max(website_visits, 1), 4)

        revenue = round(current_price * units_sold, 2)
        profit = round((current_price - prod["supplier_cost"]) * units_sold, 2)
        profit_margin = round((profit / revenue) * 100, 2) if revenue > 0 else 0.0

        weather = rng.choice(WEATHER_CONDITIONS)
        segment = rng.choice(CUSTOMER_SEGMENTS, p=[0.4, 0.4, 0.2])

        rows.append({
            "transaction_id": tx_id, "product_id": pid, "product_name": prod["product_name"],
            "category": prod["category"], "date": date_str, "day_of_week": day_of_week,
            "month": date.month, "season": season, "current_price": current_price,
            "competitor_price": round(competitor_price, 2), "original_price": prod["original_price"],
            "discount_percentage": discount_pct, "units_sold": units_sold,
            "inventory_level": inventory_level, "reorder_level": reorder_level,
            "customer_rating": prod["customer_rating"], "product_popularity": prod["product_popularity"],
            "website_visits": website_visits, "cart_additions": cart_additions,
            "conversion_rate": conversion_rate, "customer_segment": segment,
            "promotion_active": promotion_active, "holiday": holiday, "weather_condition": weather,
            "supplier_cost": prod["supplier_cost"], "profit_margin": profit_margin,
            "revenue": revenue, "profit": profit,
        })
        tx_id += 1

    return pd.DataFrame(rows)


def build_dataset_if_missing():
    os.makedirs(DATA_DIR, exist_ok=True)
    if all(os.path.exists(p) for p in [PRODUCTS_CSV, SALES_CSV, COMPETITORS_CSV]):
        return
    products_df = generate_products()
    products_df.to_csv(PRODUCTS_CSV, index=False)
    competitors_df = generate_competitors(products_df)
    competitors_df.to_csv(COMPETITORS_CSV, index=False)
    sales_df = generate_sales(products_df, competitors_df)
    sales_df.to_csv(SALES_CSV, index=False)


# ============================================================================
# 3. DATA PREPROCESSING
# ============================================================================
NUMERIC_OUTLIER_COLS = ["current_price", "competitor_price", "units_sold",
                         "revenue", "profit", "website_visits", "cart_additions"]


def handle_missing_values(df):
    df = df.copy()
    df = df.dropna(subset=["units_sold"])
    for col in df.select_dtypes(include=[np.number]).columns:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())
    for col in df.select_dtypes(include=["object", "bool"]).columns:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].mode().iloc[0])
    return df


def remove_duplicates(df):
    return df.drop_duplicates(subset=["transaction_id"]).copy()


def fix_data_types(df):
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df["promotion_active"] = df["promotion_active"].astype(bool)
    df["holiday"] = df["holiday"].astype(bool)
    for col in ["current_price", "competitor_price", "original_price", "discount_percentage",
                "customer_rating", "product_popularity", "conversion_rate", "profit_margin",
                "revenue", "profit", "supplier_cost"]:
        df[col] = df[col].astype(float)
    for col in ["units_sold", "inventory_level", "reorder_level", "website_visits",
                "cart_additions", "month"]:
        df[col] = df[col].astype(int)
    return df


def cap_outliers_iqr(df, cols=NUMERIC_OUTLIER_COLS, factor=1.5):
    df = df.copy()
    for col in cols:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        lower, upper = q1 - factor * iqr, q3 + factor * iqr
        df[col] = df[col].clip(lower=max(lower, 0), upper=upper)
    return df


def encode_categoricals(df, encoders=None):
    df = df.copy()
    fit_new = encoders is None
    encoders = encoders or {}
    for col in CATEGORICAL_COLS:
        if fit_new:
            le = LabelEncoder()
            df[col + "_enc"] = le.fit_transform(df[col].astype(str))
            encoders[col] = le
        else:
            le = encoders[col]
            df[col + "_enc"] = df[col].astype(str).map(
                lambda v: le.transform([v])[0] if v in le.classes_ else -1
            )
    return df, encoders


def run_preprocessing_pipeline(raw_csv_path):
    df = pd.read_csv(raw_csv_path)
    df = handle_missing_values(df)
    df = remove_duplicates(df)
    df = fix_data_types(df)
    df = cap_outliers_iqr(df)
    return df


def train_val_test_split(df, target_col, test_size=TEST_SIZE, val_size=VAL_SIZE, random_state=42):
    train_val, test = train_test_split(df, test_size=test_size, random_state=random_state)
    relative_val = val_size / (1 - test_size)
    train, val = train_test_split(train_val, test_size=relative_val, random_state=random_state)
    return train, val, test


# ============================================================================
# 4. FEATURE ENGINEERING
# ============================================================================
def add_time_features(df):
    df = df.copy()
    df["day"] = df["date"].dt.day
    df["week"] = df["date"].dt.isocalendar().week.astype(int)
    df["quarter"] = df["date"].dt.quarter
    df["is_weekend"] = df["date"].dt.dayofweek.isin([5, 6]).astype(int)
    df["is_holiday"] = df["holiday"].astype(int)
    return df


def add_pricing_features(df):
    df = df.copy()
    df["price_diff"] = df["current_price"] - df["competitor_price"]
    df["price_diff_pct"] = np.where(df["competitor_price"] > 0,
                                     (df["price_diff"] / df["competitor_price"]) * 100, 0)
    df["price_to_cost_ratio"] = np.where(df["supplier_cost"] > 0,
                                          df["current_price"] / df["supplier_cost"], 0)
    return df


def add_demand_features(df):
    df = df.sort_values(["product_id", "date"]).copy()
    grp = df.groupby("product_id")["units_sold"]
    df["prev_day_sales"] = grp.shift(1).fillna(0)
    df["prev_week_sales"] = grp.shift(7).fillna(0)
    df["rolling_7d_demand"] = grp.transform(lambda s: s.shift(1).rolling(7, min_periods=1).mean()).fillna(0)
    df["rolling_30d_demand"] = grp.transform(lambda s: s.shift(1).rolling(30, min_periods=1).mean()).fillna(0)
    df["demand_growth_rate"] = np.where(
        df["rolling_30d_demand"] > 0,
        (df["rolling_7d_demand"] - df["rolling_30d_demand"]) / df["rolling_30d_demand"], 0,
    )
    return df


def add_inventory_features(df):
    df = df.copy()
    safe_demand = df["rolling_7d_demand"].replace(0, np.nan)
    df["inventory_to_demand_ratio"] = (df["inventory_level"] / safe_demand).fillna(df["inventory_level"])
    df["stock_pressure"] = np.select(
        [df["inventory_level"] <= df["reorder_level"] * 0.5, df["inventory_level"] <= df["reorder_level"]],
        [2, 1], default=0,
    )
    df["inventory_shortage_indicator"] = (df["inventory_level"] < df["reorder_level"]).astype(int)
    return df


def add_customer_features(df):
    df = df.copy()
    df["engagement_rate"] = np.where(df["website_visits"] > 0,
                                      df["cart_additions"] / df["website_visits"], 0)
    return df


def build_features(df, encoders=None):
    df = add_time_features(df)
    df = add_pricing_features(df)
    df = add_demand_features(df)
    df = add_inventory_features(df)
    df = add_customer_features(df)
    df, encoders = encode_categoricals(df, encoders=encoders)
    df["promotion_active"] = df["promotion_active"].astype(int)
    return df, encoders


# ============================================================================
# 5. DEMAND PREDICTION — TRAIN, COMPARE, SELECT BEST MODEL
# ============================================================================
def get_model_zoo():
    return {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=200, max_depth=4, learning_rate=0.08, random_state=42),
        "XGBoost": XGBRegressor(n_estimators=300, max_depth=6, learning_rate=0.07, subsample=0.9,
                                 colsample_bytree=0.9, random_state=42, n_jobs=-1, verbosity=0),
    }


def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    return {"MAE": round(mae, 3), "MSE": round(mse, 3), "RMSE": round(rmse, 3), "R2": round(r2, 4)}


def train_and_compare(train_df, val_df, features=MODEL_FEATURES, target=TARGET):
    X_train, y_train = train_df[features], train_df[target]
    X_val, y_val = val_df[features], val_df[target]
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)

    models = get_model_zoo()
    fitted, metrics = {}, []
    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        preds = np.clip(model.predict(X_val_scaled), 0, None)
        m = evaluate(y_val, preds)
        m["Model"] = name
        metrics.append(m)
        fitted[name] = model

    metrics_df = pd.DataFrame(metrics)[["Model", "MAE", "MSE", "RMSE", "R2"]].sort_values("RMSE").reset_index(drop=True)
    return fitted, metrics_df, scaler


def predict_demand(model, scaler, feature_row_df, features=MODEL_FEATURES):
    X = scaler.transform(feature_row_df[features])
    return np.clip(model.predict(X), 0, None)


def train_models_if_missing():
    os.makedirs(MODELS_DIR, exist_ok=True)
    if all(os.path.exists(p) for p in [DEMAND_MODEL_PATH, SCALER_PATH, ENCODERS_PATH, METRICS_PATH, SAMPLE_PATH]):
        return
    df = run_preprocessing_pipeline(SALES_CSV)
    df, encoders = build_features(df)
    df = df.dropna(subset=MODEL_FEATURES + [TARGET])
    train_df, val_df, test_df = train_val_test_split(df, TARGET)

    fitted_models, metrics_df, scaler = train_and_compare(train_df, val_df)
    best_name = metrics_df.iloc[0]["Model"]
    best_model = fitted_models[best_name]

    joblib.dump(best_model, DEMAND_MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(encoders, ENCODERS_PATH)
    joblib.dump(metrics_df, METRICS_PATH)
    joblib.dump(train_df.sample(min(1000, len(train_df)), random_state=42), SAMPLE_PATH)


# ============================================================================
# 6. PRICE OPTIMIZATION ENGINE
# ============================================================================
def generate_candidate_prices(base_price, supplier_cost,
                               min_mult=DEFAULT_MIN_PRICE_MULTIPLIER,
                               max_mult=DEFAULT_MAX_PRICE_MULTIPLIER,
                               steps=CANDIDATE_PRICE_STEPS):
    low = max(base_price * min_mult, supplier_cost * 1.02)
    high = base_price * max_mult
    if high <= low:
        high = low * 1.1
    return np.linspace(low, high, steps)


def build_candidate_feature_rows(context_row, candidate_prices):
    rows = pd.concat([context_row] * len(candidate_prices), ignore_index=True)
    rows["current_price"] = candidate_prices
    rows["price_diff"] = rows["current_price"] - rows["competitor_price"]
    rows["price_diff_pct"] = np.where(rows["competitor_price"] > 0,
                                       (rows["price_diff"] / rows["competitor_price"]) * 100, 0)
    rows["price_to_cost_ratio"] = np.where(rows["supplier_cost"] > 0,
                                            rows["current_price"] / rows["supplier_cost"], 0)
    rows["discount_percentage"] = np.clip(
        (rows["original_price"] - rows["current_price"]) / rows["original_price"] * 100, 0, 100,
    )
    return rows


def apply_business_constraints(results_df, supplier_cost, inventory_level,
                                min_margin_pct=DEFAULT_MIN_MARGIN_PCT,
                                max_discount_pct=DEFAULT_MAX_DISCOUNT_PCT):
    df = results_df.copy()
    df["predicted_demand"] = np.minimum(df["predicted_demand"], inventory_level)
    valid = df[(df["profit_margin_pct"] >= min_margin_pct) & (df["discount_percentage"] <= max_discount_pct)]
    if valid.empty:
        df["violation_score"] = (
            np.maximum(0, min_margin_pct - df["profit_margin_pct"]) +
            np.maximum(0, df["discount_percentage"] - max_discount_pct)
        )
        valid = df.sort_values("violation_score").head(5)
    return valid


def optimize_price(model, scaler, context_row, objective="Maximum Profit",
                    min_margin_pct=DEFAULT_MIN_MARGIN_PCT, max_discount_pct=DEFAULT_MAX_DISCOUNT_PCT,
                    price_bounds=None):
    base_price = float(context_row["original_price"].iloc[0])
    supplier_cost = float(context_row["supplier_cost"].iloc[0])
    inventory_level = float(context_row["inventory_level"].iloc[0])

    if price_bounds:
        candidates = generate_candidate_prices(base_price, supplier_cost, *price_bounds)
    else:
        candidates = generate_candidate_prices(base_price, supplier_cost)

    rows = build_candidate_feature_rows(context_row, candidates)
    predicted_demand = predict_demand(model, scaler, rows, MODEL_FEATURES)

    results = pd.DataFrame({"candidate_price": candidates, "predicted_demand": predicted_demand})
    results["expected_revenue"] = results["candidate_price"] * results["predicted_demand"]
    results["expected_profit"] = (results["candidate_price"] - supplier_cost) * results["predicted_demand"]
    results["profit_margin_pct"] = np.where(results["expected_revenue"] > 0,
                                             (results["expected_profit"] / results["expected_revenue"]) * 100, 0)
    results["discount_percentage"] = np.clip((base_price - results["candidate_price"]) / base_price * 100, 0, 100)

    valid = apply_business_constraints(results, supplier_cost, inventory_level, min_margin_pct, max_discount_pct)

    if objective == "Maximum Revenue":
        best = valid.loc[valid["expected_revenue"].idxmax()]
    elif objective == "Maximum Sales":
        best = valid.loc[valid["predicted_demand"].idxmax()]
    elif objective == "Inventory Clearance":
        valid = valid.copy()
        valid["clearance_score"] = valid["predicted_demand"] / max(inventory_level, 1)
        best = valid.loc[valid["clearance_score"].idxmax()]
    else:
        best = valid.loc[valid["expected_profit"].idxmax()]

    return best, results


def inventory_pricing_signal(inventory_level, reorder_level):
    if inventory_level <= CRITICAL_INVENTORY_LEVEL:
        return "Critical stock — avoid aggressive discounts; protect margin."
    if inventory_level <= LOW_INVENTORY_LEVEL:
        return "Low stock — consider a modest price increase if demand is strong."
    if inventory_level >= HIGH_INVENTORY_LEVEL:
        return "High stock — reduce price to accelerate turnover."
    return "Inventory healthy — price primarily on demand and competition."


def explain_recommendation(context_row, best_row, avg_competitor_price):
    reasons = []
    current_price = float(context_row["current_price"].iloc[0]) if "current_price" in context_row else None
    rec_price = float(best_row["candidate_price"])
    popularity = float(context_row["product_popularity"].iloc[0])
    rolling_7d = float(context_row["rolling_7d_demand"].iloc[0])
    rolling_30d = float(context_row["rolling_30d_demand"].iloc[0])
    inventory = float(context_row["inventory_level"].iloc[0])
    reorder = float(context_row["reorder_level"].iloc[0])

    if rolling_7d > rolling_30d:
        reasons.append("Recent demand is trending upward compared to the 30-day average.")
    elif rolling_7d < rolling_30d:
        reasons.append("Recent demand is trending down compared to the 30-day average.")

    reasons.append(inventory_pricing_signal(inventory, reorder))

    if popularity >= 0.6:
        reasons.append("Product has high popularity, supporting a firmer price.")
    elif popularity <= 0.3:
        reasons.append("Product has lower popularity, limiting pricing power.")

    if rec_price < avg_competitor_price * 0.97:
        reasons.append(f"Recommended price is below the market average (₹{avg_competitor_price:,.0f}).")
    elif rec_price > avg_competitor_price * 1.03:
        reasons.append(f"Recommended price is above the market average (₹{avg_competitor_price:,.0f}).")
    else:
        reasons.append(f"Recommended price is close to the market average (₹{avg_competitor_price:,.0f}).")

    if current_price is not None:
        change_pct = (rec_price - current_price) / current_price * 100
        if abs(change_pct) >= 1:
            direction = "increase" if change_pct > 0 else "decrease"
            reasons.append(f"This is a {abs(change_pct):.1f}% price {direction} from the current price.")

    return reasons


# ============================================================================
# 7. COMPETITOR ANALYSIS
# ============================================================================
def get_latest_competitor_snapshot(competitors_df, product_id):
    subset = competitors_df[competitors_df["product_id"] == product_id].sort_values("date")
    return None if subset.empty else subset.iloc[-1]


def competitor_summary(our_price, competitor_row):
    comp_a, comp_b, comp_c = competitor_row["competitor_a_price"], competitor_row["competitor_b_price"], competitor_row["competitor_c_price"]
    avg_market = (comp_a + comp_b + comp_c) / 3
    price_gap = our_price - avg_market
    price_gap_pct = (price_gap / avg_market) * 100 if avg_market else 0
    competitive_index = (our_price / avg_market) * 100 if avg_market else 100

    if price_gap_pct > 8:
        position = "Significantly above market average"
    elif price_gap_pct > 2:
        position = "Slightly above market average"
    elif price_gap_pct < -8:
        position = "Significantly below market average"
    elif price_gap_pct < -2:
        position = "Slightly below market average"
    else:
        position = "In line with market average"

    return {
        "our_price": round(our_price, 2), "competitor_a": round(comp_a, 2), "competitor_b": round(comp_b, 2),
        "competitor_c": round(comp_c, 2), "average_market_price": round(avg_market, 2),
        "price_gap": round(price_gap, 2), "price_gap_pct": round(price_gap_pct, 2),
        "competitive_index": round(competitive_index, 1), "market_position": position,
    }


def category_competitor_overview(sales_df):
    df = sales_df.copy()
    df["price_gap_pct"] = (df["current_price"] - df["competitor_price"]) / df["competitor_price"] * 100
    return (df.groupby("category")
            .agg(avg_price_gap_pct=("price_gap_pct", "mean"), avg_our_price=("current_price", "mean"),
                 avg_competitor_price=("competitor_price", "mean"))
            .reset_index().round(2))


# ============================================================================
# 8. DEMAND FORECASTING
# ============================================================================
def _daily_series(sales_df, product_id):
    df = sales_df[sales_df["product_id"] == product_id].copy()
    df["date"] = pd.to_datetime(df["date"])
    return df.groupby("date")["units_sold"].sum().asfreq("D").fillna(0)


def forecast_demand(sales_df, product_id, horizon=7, n_bootstrap=200):
    daily = _daily_series(sales_df, product_id)
    if len(daily) < 5 or daily.sum() == 0:
        mean_val = max(daily.mean(), 1.0) if len(daily) else 1.0
        future_dates = pd.date_range((daily.index.max() if len(daily) else pd.Timestamp.today()) + pd.Timedelta(days=1), periods=horizon)
        return pd.DataFrame({"date": future_dates, "forecast": [mean_val] * horizon,
                              "lower_ci": [mean_val * 0.6] * horizon, "upper_ci": [mean_val * 1.4] * horizon})

    window = daily.tail(60)
    x = np.arange(len(window))
    y = window.values
    slope, intercept = np.polyfit(x, y, 1)
    dow_index = window.groupby(window.index.dayofweek).mean() / max(window.mean(), 1e-6)
    residuals = y - (slope * x + intercept)

    last_x = len(window) - 1
    future_dates = pd.date_range(daily.index.max() + pd.Timedelta(days=1), periods=horizon)
    forecasts, lowers, uppers = [], [], []
    boot_rng = np.random.default_rng(7)
    for i, d in enumerate(future_dates, start=1):
        trend_val = slope * (last_x + i) + intercept
        seasonal_factor = dow_index.get(d.dayofweek, 1.0)
        point = max(trend_val * seasonal_factor, 0)
        sim = point + boot_rng.choice(residuals, size=n_bootstrap, replace=True) * 0.5
        sim = np.clip(sim, 0, None)
        lower, upper = np.percentile(sim, [10, 90])
        forecasts.append(round(point, 1)); lowers.append(round(lower, 1)); uppers.append(round(upper, 1))

    return pd.DataFrame({"date": future_dates, "forecast": forecasts, "lower_ci": lowers, "upper_ci": uppers})


def historical_demand(sales_df, product_id, days=60):
    daily = _daily_series(sales_df, product_id)
    return daily.tail(days).reset_index().rename(columns={"index": "date", "units_sold": "actual_demand"})


# ============================================================================
# 9. ANOMALY DETECTION
# ============================================================================
ANOMALY_FEATURES = ["units_sold", "revenue", "current_price", "competitor_price", "inventory_level"]


def detect_anomalies(sales_df, contamination=0.02, random_state=42):
    df = sales_df.copy()
    X = df[ANOMALY_FEATURES].fillna(0)
    model = IsolationForest(n_estimators=200, contamination=contamination, random_state=random_state)
    preds = model.fit_predict(X)
    df["is_anomaly"] = preds == -1
    df["anomaly_score"] = model.score_samples(X)

    means, stds = X.mean(), X.std().replace(0, 1)
    z = (X - means) / stds
    reasons = []
    for idx, row in df.iterrows():
        if not row["is_anomaly"]:
            reasons.append("")
            continue
        zrow = z.loc[idx]
        top_feature = zrow.abs().idxmax()
        direction = "spike" if zrow[top_feature] > 0 else "drop"
        reasons.append(f"Unusual {direction} in {top_feature.replace('_', ' ')}")
    df["reason"] = reasons
    return df


def anomaly_summary(anomaly_df, top_n=25):
    cols = ["transaction_id", "product_id", "product_name", "date", "units_sold", "revenue",
            "current_price", "competitor_price", "inventory_level", "anomaly_score", "reason"]
    return anomaly_df[anomaly_df["is_anomaly"]][cols].sort_values("anomaly_score").head(top_n).reset_index(drop=True)


# ============================================================================
# 10. SHAP EXPLAINABILITY
# ============================================================================
def build_explainer(model, background_df, features=MODEL_FEATURES, sample_size=200):
    background = background_df[features]
    if len(background) > sample_size:
        background = background.sample(sample_size, random_state=42)
    model_type = type(model).__name__
    if model_type in ("RandomForestRegressor", "GradientBoostingRegressor", "XGBRegressor"):
        return shap.TreeExplainer(model)
    return shap.Explainer(model.predict, background)


def global_feature_importance(explainer, X_df, features=MODEL_FEATURES, sample_size=300):
    sample = X_df[features]
    if len(sample) > sample_size:
        sample = sample.sample(sample_size, random_state=42)
    sv = explainer(sample) if hasattr(explainer, "__call__") else explainer.shap_values(sample)
    values = sv.values if hasattr(sv, "values") else sv
    importance = np.abs(values).mean(axis=0)
    return pd.DataFrame({"feature": features, "mean_abs_shap": importance}).sort_values(
        "mean_abs_shap", ascending=False).reset_index(drop=True)


def explain_single_prediction(explainer, row_df, features=MODEL_FEATURES, top_n=6):
    X = row_df[features]
    sv = explainer(X) if hasattr(explainer, "__call__") else explainer.shap_values(X)
    values = sv.values[0] if hasattr(sv, "values") else np.array(sv)[0]
    contributions = sorted(zip(features, values), key=lambda t: t[1], reverse=True)
    positive = [c for c in contributions if c[1] > 0][:top_n]
    negative = [c for c in contributions if c[1] < 0][-top_n:]
    negative.sort(key=lambda t: t[1])
    return positive, negative


# ============================================================================
# 11. SQLITE DATABASE
# ============================================================================
SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY, product_name TEXT, category TEXT,
    supplier_cost REAL, original_price REAL, product_popularity REAL, customer_rating REAL
);
CREATE TABLE IF NOT EXISTS sales (
    transaction_id INTEGER PRIMARY KEY, product_id INTEGER, date TEXT, current_price REAL,
    competitor_price REAL, units_sold INTEGER, revenue REAL, profit REAL, inventory_level INTEGER
);
CREATE TABLE IF NOT EXISTS competitors (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, date TEXT,
    competitor_a_price REAL, competitor_b_price REAL, competitor_c_price REAL
);
CREATE TABLE IF NOT EXISTS price_recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    objective TEXT, current_price REAL, recommended_price REAL, predicted_demand REAL,
    expected_revenue REAL, expected_profit REAL, profit_margin_pct REAL
);
CREATE TABLE IF NOT EXISTS anomalies (
    id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id INTEGER, product_id INTEGER, date TEXT,
    reason TEXT, anomaly_score REAL, detected_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


@contextmanager
def get_connection():
    os.makedirs(WORK_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    with get_connection() as conn:
        conn.executescript(SCHEMA)
        conn.commit()


def load_products_table(products_df):
    with get_connection() as conn:
        products_df.to_sql("products", conn, if_exists="replace", index=False)


def load_sales_table(sales_df):
    cols = ["transaction_id", "product_id", "date", "current_price", "competitor_price",
            "units_sold", "revenue", "profit", "inventory_level"]
    with get_connection() as conn:
        sales_df[cols].to_sql("sales", conn, if_exists="replace", index=False)


def load_competitors_table(competitors_df):
    with get_connection() as conn:
        competitors_df.to_sql("competitors", conn, if_exists="replace", index=False)


def save_price_recommendation(product_id, objective, current_price, recommended_price,
                               predicted_demand, expected_revenue, expected_profit, profit_margin_pct):
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO price_recommendations
               (product_id, objective, current_price, recommended_price, predicted_demand,
                expected_revenue, expected_profit, profit_margin_pct) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (product_id, objective, current_price, recommended_price, predicted_demand,
             expected_revenue, expected_profit, profit_margin_pct))
        conn.commit()


def get_recommendation_history(product_id=None, limit=50):
    query = "SELECT * FROM price_recommendations"
    params = ()
    if product_id is not None:
        query += " WHERE product_id = ?"
        params = (product_id,)
    query += " ORDER BY created_at DESC LIMIT ?"
    params = params + (limit,)
    with get_connection() as conn:
        return pd.read_sql_query(query, conn, params=params)


def save_anomalies(anomaly_summary_df):
    if anomaly_summary_df.empty:
        return
    with get_connection() as conn:
        for _, row in anomaly_summary_df.iterrows():
            conn.execute(
                """INSERT INTO anomalies (transaction_id, product_id, date, reason, anomaly_score)
                   VALUES (?, ?, ?, ?, ?)""",
                (int(row["transaction_id"]), int(row["product_id"]), str(row["date"]),
                 row["reason"], float(row["anomaly_score"])))
        conn.commit()


def get_saved_anomalies(limit=100):
    with get_connection() as conn:
        return pd.read_sql_query("SELECT * FROM anomalies ORDER BY detected_at DESC LIMIT ?", conn, params=(limit,))


# ============================================================================
# 12. CACHED APP-LEVEL LOADERS
# ============================================================================
@st.cache_resource(show_spinner="Training demand prediction models (first run only)...")
def get_model_artifacts():
    train_models_if_missing()
    model = joblib.load(DEMAND_MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    encoders = joblib.load(ENCODERS_PATH)
    metrics_df = joblib.load(METRICS_PATH)
    return model, scaler, encoders, metrics_df


@st.cache_data(show_spinner=False)
def get_engineered_data():
    _, _, encoders, _ = get_model_artifacts()
    df = run_preprocessing_pipeline(SALES_CSV)
    df, _ = build_features(df, encoders=encoders)
    return df


@st.cache_data(show_spinner=False)
def get_raw_sales():
    return pd.read_csv(SALES_CSV)


@st.cache_data(show_spinner=False)
def get_products():
    return pd.read_csv(PRODUCTS_CSV)


@st.cache_data(show_spinner=False)
def get_competitors():
    return pd.read_csv(COMPETITORS_CSV)


@st.cache_resource(show_spinner=False)
def get_shap_explainer():
    model, _, _, _ = get_model_artifacts()
    background = joblib.load(SAMPLE_PATH)
    return build_explainer(model, background)


def ensure_database_loaded():
    init_db()
    if "db_loaded" not in st.session_state:
        load_products_table(get_products())
        load_sales_table(get_raw_sales())
        load_competitors_table(get_competitors())
        st.session_state["db_loaded"] = True


def latest_context_row(engineered_df, product_id):
    subset = engineered_df[engineered_df["product_id"] == product_id].sort_values("date")
    return None if subset.empty else subset.tail(1).reset_index(drop=True)


CUSTOM_CSS = """
.kpi-card { background: linear-gradient(135deg, #1f2937 0%, #111827 100%); border-radius: 12px;
    padding: 16px 18px; color: #f9fafb; border: 1px solid #374151; }
.kpi-label { font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.04em; color: #9ca3af; margin-bottom: 4px; }
.kpi-value { font-size: 1.5rem; font-weight: 700; }
.reason-box { background: #0f172a; border-left: 3px solid #3b82f6; border-radius: 6px; padding: 10px 14px; margin-bottom: 6px; }
"""


# ============================================================================
# 13. DASHBOARD PAGE
# ============================================================================
def page_dashboard():
    st.title("💹 AI-Powered Dynamic Pricing Engine")
    st.caption("End-to-end ML system for demand prediction, price optimization and business insight.")

    ensure_database_loaded()
    sales_df = get_raw_sales()
    products_df = get_products()

    with st.expander("🔍 Filters", expanded=False):
        c1, c2, c3 = st.columns(3)
        categories = ["All"] + sorted(sales_df["category"].unique().tolist())
        category_filter = c1.selectbox("Category", categories)
        segments = ["All"] + sorted(sales_df["customer_segment"].unique().tolist())
        segment_filter = c2.selectbox("Customer Segment", segments)
        date_range = c3.date_input(
            "Date range",
            value=(pd.to_datetime(sales_df["date"]).min(), pd.to_datetime(sales_df["date"]).max()),
        )

    df = sales_df.copy()
    df["date"] = pd.to_datetime(df["date"])
    if category_filter != "All":
        df = df[df["category"] == category_filter]
    if segment_filter != "All":
        df = df[df["customer_segment"] == segment_filter]
    if isinstance(date_range, tuple) and len(date_range) == 2:
        df = df[(df["date"] >= pd.to_datetime(date_range[0])) & (df["date"] <= pd.to_datetime(date_range[1]))]

    total_revenue, total_units = df["revenue"].sum(), df["units_sold"].sum()
    avg_price, avg_profit = df["current_price"].mean(), df["profit"].mean()
    avg_margin, avg_inventory = df["profit_margin"].mean(), df["inventory_level"].mean()

    kpis = [
        ("Total Revenue", f"₹{total_revenue:,.0f}"), ("Total Units Sold", f"{total_units:,.0f}"),
        ("Average Price", f"₹{avg_price:,.0f}"), ("Average Profit / Txn", f"₹{avg_profit:,.0f}"),
        ("Average Profit Margin", f"{avg_margin:,.1f}%"), ("Average Inventory", f"{avg_inventory:,.0f} units"),
    ]
    cols = st.columns(len(kpis))
    for col, (label, value) in zip(cols, kpis):
        col.markdown(f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
                      f'<div class="kpi-value">{value}</div></div>', unsafe_allow_html=True)

    st.markdown("---")
    tab1, tab2, tab3, tab4 = st.tabs(
        ["Revenue & Demand Trend", "Price vs Demand/Profit", "Category Performance", "Inventory Trend"])

    with tab1:
        daily = df.groupby("date").agg(revenue=("revenue", "sum"), units_sold=("units_sold", "sum")).reset_index()
        c1, c2 = st.columns(2)
        c1.plotly_chart(px.line(daily, x="date", y="revenue", title="Revenue Trend"), use_container_width=True)
        c2.plotly_chart(px.line(daily, x="date", y="units_sold", title="Demand Trend"), use_container_width=True)

    with tab2:
        sample = df.sample(min(3000, len(df)), random_state=1)
        c1, c2 = st.columns(2)
        c1.plotly_chart(px.scatter(sample, x="current_price", y="units_sold", color="category",
                                    title="Price vs Demand", opacity=0.5), use_container_width=True)
        c2.plotly_chart(px.scatter(sample, x="current_price", y="profit", color="category",
                                    title="Price vs Profit", opacity=0.5), use_container_width=True)

    with tab3:
        cat_perf = df.groupby("category").agg(revenue=("revenue", "sum"), profit=("profit", "sum"),
                                                units_sold=("units_sold", "sum")).reset_index().sort_values("revenue", ascending=False)
        st.plotly_chart(px.bar(cat_perf, x="category", y=["revenue", "profit"], barmode="group",
                                title="Revenue & Profit by Category"), use_container_width=True)
        st.dataframe(cat_perf, use_container_width=True, hide_index=True)

    with tab4:
        inv = df.groupby("date")["inventory_level"].mean().reset_index()
        st.plotly_chart(px.line(inv, x="date", y="inventory_level", title="Average Inventory Level Over Time"),
                         use_container_width=True)

    st.markdown("---")
    st.subheader("⚠️ Live Alerts")
    latest_by_product = df.sort_values("date").groupby("product_id").tail(1).merge(
        products_df[["product_id"]], on="product_id", how="inner")

    alerts = []
    for _, row in latest_by_product.iterrows():
        if row["inventory_level"] <= CRITICAL_INVENTORY_LEVEL:
            alerts.append(("🔴 Critical Inventory", row["product_name"], f"Only {row['inventory_level']} units left"))
        elif row["inventory_level"] <= LOW_INVENTORY_LEVEL:
            alerts.append(("🟠 Low Inventory", row["product_name"], f"{row['inventory_level']} units left, watch reorder point"))
        if row["current_price"] > row["competitor_price"] * 1.08:
            alerts.append(("🟡 Price Above Competitor", row["product_name"],
                            f"₹{row['current_price']:,.0f} vs market ₹{row['competitor_price']:,.0f}"))
        if row["inventory_level"] >= HIGH_INVENTORY_LEVEL:
            alerts.append(("🟢 Opportunity for Discount", row["product_name"],
                            f"High stock ({row['inventory_level']} units) — consider a discount"))
        if row["current_price"] < row["competitor_price"] * 0.92:
            alerts.append(("🔵 Opportunity for Price Increase", row["product_name"],
                            f"₹{row['current_price']:,.0f} is well below market ₹{row['competitor_price']:,.0f}"))

    if alerts:
        st.dataframe(pd.DataFrame(alerts, columns=["Alert", "Product", "Detail"]).head(30),
                      use_container_width=True, hide_index=True)
    else:
        st.success("No alerts — all products within normal thresholds.")


# ============================================================================
# 14. PRICE OPTIMIZER PAGE
# ============================================================================
def page_price_optimizer():
    st.title("🎯 Price Optimizer")
    model, scaler, encoders, _ = get_model_artifacts()
    engineered_df = get_engineered_data()
    products_df = get_products()

    c1, c2, c3 = st.columns(3)
    product_name = c1.selectbox("Product", sorted(products_df["product_name"].unique()))
    product_id = int(products_df.loc[products_df.product_name == product_name, "product_id"].iloc[0])
    objective = c2.selectbox("Optimization Objective", OPTIMIZATION_OBJECTIVES)
    context = latest_context_row(engineered_df, product_id)

    if context is None:
        st.error("No history found for this product.")
        return

    season_choice = c3.selectbox("Scenario", ["Normal Day", "Weekend", "Festival", "Holiday", "Peak Season"])

    with st.expander("Advanced business constraints"):
        a1, a2 = st.columns(2)
        min_margin = a1.slider("Minimum profit margin (%)", 0, 50, int(DEFAULT_MIN_MARGIN_PCT))
        max_discount = a2.slider("Maximum discount allowed (%)", 0, 60, int(DEFAULT_MAX_DISCOUNT_PCT))

    context = context.copy()
    if season_choice == "Weekend":
        context["is_weekend"] = 1
    elif season_choice == "Festival":
        context["is_holiday"] = 1
        context["promotion_active"] = 1
    elif season_choice == "Holiday":
        context["is_holiday"] = 1
    elif season_choice == "Peak Season":
        context["rolling_7d_demand"] = context["rolling_7d_demand"] * 1.3

    st.markdown("---")
    if st.button("🔮 Generate Price Recommendation", type="primary"):
        best, all_candidates = optimize_price(model, scaler, context, objective=objective,
                                               min_margin_pct=min_margin, max_discount_pct=max_discount)
        current_price = float(context["current_price"].iloc[0])
        avg_competitor_price = float(context["competitor_price"].iloc[0])
        reasons = explain_recommendation(context, best, avg_competitor_price)
        price_change_pct = (best["candidate_price"] - current_price) / current_price * 100

        st.subheader(f"Recommended Price for {product_name}")
        k1, k2, k3, k4, k5 = st.columns(5)
        k1.metric("Recommended Price", f"₹{best['candidate_price']:,.0f}", f"{price_change_pct:+.1f}%")
        k2.metric("Predicted Demand", f"{best['predicted_demand']:,.0f} units")
        k3.metric("Expected Revenue", f"₹{best['expected_revenue']:,.0f}")
        k4.metric("Expected Profit", f"₹{best['expected_profit']:,.0f}")
        k5.metric("Profit Margin", f"{best['profit_margin_pct']:.1f}%")

        st.markdown("#### Why this price?")
        for r in reasons:
            st.markdown(f'<div class="reason-box">• {r}</div>', unsafe_allow_html=True)

        save_price_recommendation(product_id, objective, current_price, float(best["candidate_price"]),
                                   float(best["predicted_demand"]), float(best["expected_revenue"]),
                                   float(best["expected_profit"]), float(best["profit_margin_pct"]))

        st.markdown("---")
        st.markdown("#### Price sensitivity curves")
        t1, t2, t3 = st.tabs(["Revenue vs Price", "Profit vs Price", "Demand vs Price"])
        with t1:
            st.plotly_chart(px.line(all_candidates, x="candidate_price", y="expected_revenue", title="Revenue Curve")
                             .add_vline(x=best["candidate_price"], line_dash="dash"), use_container_width=True)
        with t2:
            st.plotly_chart(px.line(all_candidates, x="candidate_price", y="expected_profit", title="Profit Curve")
                             .add_vline(x=best["candidate_price"], line_dash="dash"), use_container_width=True)
        with t3:
            st.plotly_chart(px.line(all_candidates, x="candidate_price", y="predicted_demand",
                                     title="Demand Curve (Price Sensitivity)")
                             .add_vline(x=best["candidate_price"], line_dash="dash"), use_container_width=True)

        with st.expander("All evaluated candidate prices"):
            st.dataframe(all_candidates.round(2), use_container_width=True, hide_index=True)
    else:
        st.info("Set the product, objective and scenario above, then click **Generate Price Recommendation**.")


# ============================================================================
# 15. DEMAND FORECASTING PAGE
# ============================================================================
def page_demand_forecasting():
    st.title("📈 Demand Forecasting")
    sales_df = get_raw_sales()
    products_df = get_products()

    c1, c2 = st.columns([2, 1])
    product_name = c1.selectbox("Product", sorted(products_df["product_name"].unique()), key="fc_product")
    horizon = c2.selectbox("Forecast horizon", [7, 14, 30], format_func=lambda h: f"Next {h} days")
    product_id = int(products_df.loc[products_df.product_name == product_name, "product_id"].iloc[0])

    hist = historical_demand(sales_df, product_id, days=60)
    fc = forecast_demand(sales_df, product_id, horizon=horizon)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist["date"], y=hist["actual_demand"], mode="lines",
                              name="Historical Demand", line=dict(color="#3b82f6")))
    fig.add_trace(go.Scatter(x=fc["date"], y=fc["forecast"], mode="lines+markers",
                              name="Forecast", line=dict(color="#f97316")))
    fig.add_trace(go.Scatter(x=pd.concat([fc["date"], fc["date"][::-1]]),
                              y=pd.concat([fc["upper_ci"], fc["lower_ci"][::-1]]),
                              fill="toself", fillcolor="rgba(249,115,22,0.15)",
                              line=dict(color="rgba(0,0,0,0)"), name="Confidence Interval", showlegend=True))
    fig.update_layout(title=f"Demand Forecast — {product_name}", xaxis_title="Date", yaxis_title="Units")
    st.plotly_chart(fig, use_container_width=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Avg Historical Demand (60d)", f"{hist['actual_demand'].mean():,.1f} units/day")
    c2.metric(f"Avg Forecast Demand ({horizon}d)", f"{fc['forecast'].mean():,.1f} units/day")
    change = (fc["forecast"].mean() - hist["actual_demand"].mean()) / max(hist["actual_demand"].mean(), 1e-6) * 100
    c3.metric("Expected Change", f"{change:+.1f}%")

    with st.expander("Forecast table"):
        st.dataframe(fc, use_container_width=True, hide_index=True)

    st.caption("Forecast combines a recent linear trend with day-of-week seasonality; the shaded band "
               "is a bootstrap confidence interval built from historical residuals.")


# ============================================================================
# 16. COMPETITOR ANALYSIS PAGE
# ============================================================================
def page_competitor_analysis():
    st.title("🏷️ Competitor Price Analysis")
    sales_df = get_raw_sales()
    products_df = get_products()
    competitors_df = get_competitors()

    product_name = st.selectbox("Product", sorted(products_df["product_name"].unique()), key="ca_product")
    product_id = int(products_df.loc[products_df.product_name == product_name, "product_id"].iloc[0])

    latest_sale = sales_df[sales_df.product_id == product_id].sort_values("date").tail(1)
    our_price = float(latest_sale["current_price"].iloc[0]) if not latest_sale.empty else 0.0

    snap = get_latest_competitor_snapshot(competitors_df, product_id)
    if snap is None:
        st.warning("No competitor data for this product.")
        return

    summary = competitor_summary(our_price, snap)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Our Price", f"₹{summary['our_price']:,.0f}")
    c2.metric("Average Market Price", f"₹{summary['average_market_price']:,.0f}")
    c3.metric("Price Gap", f"₹{summary['price_gap']:,.0f}", f"{summary['price_gap_pct']:+.1f}%")
    c4.metric("Competitive Index", f"{summary['competitive_index']:.1f}", help="100 = exactly at market average")
    st.info(f"**Market position:** {summary['market_position']}")

    comp_chart_df = pd.DataFrame({"Seller": ["Us", "Competitor A", "Competitor B", "Competitor C"],
                                   "Price": [summary["our_price"], summary["competitor_a"],
                                             summary["competitor_b"], summary["competitor_c"]]})
    st.plotly_chart(px.bar(comp_chart_df, x="Seller", y="Price", color="Seller", title="Price Comparison"),
                     use_container_width=True)

    history = competitors_df[competitors_df.product_id == product_id].tail(60)
    hist_long = history.melt(id_vars="date", value_vars=["competitor_a_price", "competitor_b_price", "competitor_c_price"],
                              var_name="competitor", value_name="price")
    st.plotly_chart(px.line(hist_long, x="date", y="price", color="competitor",
                             title="Competitor Price Trend (last 60 days)"), use_container_width=True)

    st.markdown("---")
    st.subheader("Category-level competitive overview")
    overview = category_competitor_overview(sales_df)
    st.dataframe(overview, use_container_width=True, hide_index=True)
    st.plotly_chart(px.bar(overview, x="category", y="avg_price_gap_pct",
                            title="Average Price Gap vs Competitor by Category (%)",
                            color="avg_price_gap_pct", color_continuous_scale="RdYlGn_r"), use_container_width=True)


# ============================================================================
# 17. WHAT-IF SIMULATOR PAGE
# ============================================================================
def page_what_if_simulator():
    st.title("🧪 What-If Price Simulator")
    model, scaler, encoders, _ = get_model_artifacts()
    engineered_df = get_engineered_data()
    products_df = get_products()

    product_name = st.selectbox("Product", sorted(products_df["product_name"].unique()), key="wi_product")
    product_id = int(products_df.loc[products_df.product_name == product_name, "product_id"].iloc[0])

    base_row = engineered_df[engineered_df.product_id == product_id].sort_values("date").tail(1)
    if base_row.empty:
        st.error("No history found for this product.")
        return

    current_price = float(base_row["current_price"].iloc[0])
    supplier_cost = float(base_row["supplier_cost"].iloc[0])
    st.markdown(f"**Current price:** ₹{current_price:,.0f}  |  **Supplier cost:** ₹{supplier_cost:,.0f}")

    c1, c2, c3 = st.columns(3)
    new_price = c1.number_input("Simulated Price (₹)", min_value=1.0, value=round(current_price, 0), step=10.0)
    inventory = c2.number_input("Inventory", min_value=0, value=int(base_row["inventory_level"].iloc[0]))
    discount_pct = c3.number_input("Discount (%)", min_value=0.0, max_value=90.0, value=0.0, step=1.0)

    c4, c5 = st.columns(2)
    competitor_price = c4.number_input("Competitor Price (₹)", min_value=1.0, value=float(base_row["competitor_price"].iloc[0]))
    promotion = c5.selectbox("Promotion Active?", ["No", "Yes"]) == "Yes"

    if st.button("▶️ Run Simulation", type="primary"):
        sim_row = base_row.copy()
        effective_price = new_price * (1 - discount_pct / 100)
        sim_row["current_price"] = effective_price
        sim_row["inventory_level"] = inventory
        sim_row["competitor_price"] = competitor_price
        sim_row["discount_percentage"] = discount_pct
        sim_row["promotion_active"] = int(promotion)
        sim_row["price_diff"] = sim_row["current_price"] - sim_row["competitor_price"]
        sim_row["price_diff_pct"] = (sim_row["price_diff"] / sim_row["competitor_price"]) * 100
        sim_row["price_to_cost_ratio"] = sim_row["current_price"] / supplier_cost

        predicted_demand = float(predict_demand(model, scaler, sim_row, MODEL_FEATURES)[0])
        predicted_demand = min(predicted_demand, inventory) if inventory > 0 else predicted_demand
        revenue = effective_price * predicted_demand
        profit = (effective_price - supplier_cost) * predicted_demand
        margin = (profit / revenue * 100) if revenue > 0 else 0

        baseline_demand = float(predict_demand(model, scaler, base_row, MODEL_FEATURES)[0])
        demand_change_pct = ((predicted_demand - baseline_demand) / baseline_demand * 100) if baseline_demand > 0 else 0

        st.markdown("### Simulation Result")
        k1, k2, k3, k4, k5 = st.columns(5)
        k1.metric("Simulated Price", f"₹{effective_price:,.0f}")
        k2.metric("Expected Demand", f"{predicted_demand:,.0f} units", f"{demand_change_pct:+.1f}%")
        k3.metric("Expected Revenue", f"₹{revenue:,.0f}")
        k4.metric("Expected Profit", f"₹{profit:,.0f}")
        k5.metric("Profit Margin", f"{margin:.1f}%")

        st.markdown("---")
        comparison = pd.DataFrame({
            "Scenario": ["Current", "Simulated"], "Price": [current_price, effective_price],
            "Predicted Demand": [baseline_demand, predicted_demand],
            "Revenue": [current_price * baseline_demand, revenue],
            "Profit": [(current_price - supplier_cost) * baseline_demand, profit],
        })
        st.dataframe(comparison.round(2), use_container_width=True, hide_index=True)
    else:
        st.info("Adjust the scenario above and click **Run Simulation**.")


# ============================================================================
# 18. PRODUCT ANALYTICS PAGE
# ============================================================================
def page_product_analytics():
    st.title("📊 Product Analytics")
    sales_df = get_raw_sales().copy()
    sales_df["date"] = pd.to_datetime(sales_df["date"])

    c1, c2, c3, c4 = st.columns(4)
    category = c1.selectbox("Category", ["All"] + sorted(sales_df["category"].unique().tolist()), key="pa_cat")
    product = c2.selectbox("Product", ["All"] + sorted(sales_df["product_name"].unique().tolist()), key="pa_prod")
    segment = c3.selectbox("Customer Segment", ["All"] + sorted(sales_df["customer_segment"].unique().tolist()), key="pa_seg")
    date_range = c4.date_input("Date range", value=(sales_df["date"].min(), sales_df["date"].max()), key="pa_dates")

    df = sales_df.copy()
    if category != "All":
        df = df[df["category"] == category]
    if product != "All":
        df = df[df["product_name"] == product]
    if segment != "All":
        df = df[df["customer_segment"] == segment]
    if isinstance(date_range, tuple) and len(date_range) == 2:
        df = df[(df["date"] >= pd.to_datetime(date_range[0])) & (df["date"] <= pd.to_datetime(date_range[1]))]

    def price_elasticity(group):
        g = group.sort_values("date")
        price_pct_change = g["current_price"].pct_change()
        demand_pct_change = g["units_sold"].pct_change()
        valid = (price_pct_change.abs() > 1e-6) & price_pct_change.notna() & demand_pct_change.notna()
        if valid.sum() == 0:
            return np.nan
        ratios = (demand_pct_change[valid] / price_pct_change[valid]).replace([np.inf, -np.inf], np.nan).dropna()
        return ratios.median() if len(ratios) else np.nan

    def elasticity_label(e):
        if pd.isna(e):
            return "Insufficient data"
        if e >= -1:
            return "Inelastic"
        if e <= -2:
            return "Highly Elastic"
        return "Elastic"

    agg = df.groupby(["product_id", "product_name", "category"]).agg(
        total_sales=("units_sold", "sum"), total_revenue=("revenue", "sum"), total_profit=("profit", "sum"),
        avg_demand=("units_sold", "mean"), avg_inventory=("inventory_level", "mean"),
        avg_price=("current_price", "mean"), avg_competitor_price=("competitor_price", "mean"),
    ).reset_index()

    elasticity_vals = df.groupby("product_id").apply(price_elasticity, include_groups=False)
    agg["price_elasticity"] = agg["product_id"].map(elasticity_vals)
    agg["elasticity_type"] = agg["price_elasticity"].apply(elasticity_label)
    agg = agg.round(2).sort_values("total_revenue", ascending=False)

    st.dataframe(agg, use_container_width=True, hide_index=True)

    st.markdown("---")
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(agg.head(15), x="product_name", y="total_revenue", color="category",
                            title="Top 15 Products by Revenue"), use_container_width=True)
    c2.plotly_chart(px.pie(agg, names="elasticity_type", title="Product Elasticity Distribution"),
                     use_container_width=True)

    st.download_button("⬇️ Download this table as CSV", data=agg.to_csv(index=False).encode("utf-8"),
                        file_name="product_analytics.csv", mime="text/csv")


# ============================================================================
# 19. ANOMALY DETECTION PAGE
# ============================================================================
def page_anomaly_detection():
    st.title("🚨 Anomaly Detection")
    sales_df = get_raw_sales()
    contamination = st.slider("Sensitivity (expected anomaly rate)", 0.005, 0.10, 0.02, 0.005)

    with st.spinner("Scanning transactions for anomalies..."):
        result_df = detect_anomalies(sales_df, contamination=contamination)
        top_anomalies = anomaly_summary(result_df, top_n=50)

    st.metric("Anomalies Detected", f"{result_df['is_anomaly'].sum():,} / {len(result_df):,} transactions")
    st.plotly_chart(px.scatter(result_df, x="current_price", y="units_sold", color="is_anomaly",
                                color_discrete_map={True: "#ef4444", False: "#3b82f6"},
                                title="Price vs Demand — Anomalies Highlighted", opacity=0.6), use_container_width=True)

    st.subheader("Most unusual transactions")
    st.dataframe(top_anomalies, use_container_width=True, hide_index=True)

    if st.button("💾 Save these anomalies to database"):
        save_anomalies(top_anomalies)
        st.success(f"Saved {len(top_anomalies)} anomalies.")

    with st.expander("Previously saved anomalies"):
        st.dataframe(get_saved_anomalies(), use_container_width=True, hide_index=True)

    st.caption("Detection uses an Isolation Forest over price, revenue, demand, competitor price and "
               "inventory jointly, so a transaction is flagged when its combination of signals is unusual "
               "— not just a single extreme value.")


# ============================================================================
# 20. MODEL PERFORMANCE PAGE
# ============================================================================
def page_model_performance():
    st.title("🧠 Model Performance & Explainability")
    model, scaler, encoders, metrics_df = get_model_artifacts()

    st.subheader("Model comparison (validation set)")
    st.dataframe(metrics_df, use_container_width=True, hide_index=True)
    st.plotly_chart(px.bar(metrics_df, x="Model", y="RMSE", title="RMSE by Model (lower is better)",
                            color="RMSE", color_continuous_scale="Blues_r"), use_container_width=True)
    st.success(f"**Selected model:** {metrics_df.iloc[0]['Model']} — lowest RMSE, "
               f"R² = {metrics_df.iloc[0]['R2']:.4f}")

    st.markdown("---")
    st.subheader("Global feature importance (SHAP)")
    engineered_df = get_engineered_data()
    explainer = get_shap_explainer()

    with st.spinner("Computing SHAP values..."):
        importance_df = global_feature_importance(explainer, engineered_df)
    st.plotly_chart(px.bar(importance_df.head(15), x="mean_abs_shap", y="feature", orientation="h",
                            title="Top 15 Features Driving Demand Predictions"), use_container_width=True)

    st.markdown("---")
    st.subheader("Explain a single product's prediction")
    products_df = get_products()
    product_name = st.selectbox("Product", sorted(products_df["product_name"].unique()), key="mp_product")
    product_id = int(products_df.loc[products_df.product_name == product_name, "product_id"].iloc[0])
    row = latest_context_row(engineered_df, product_id)

    if row is not None:
        with st.spinner("Explaining prediction..."):
            positive, negative = explain_single_prediction(explainer, row)
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**Factors increasing demand**")
            for feat, val in positive:
                st.markdown(f"- {feat.replace('_', ' ')} (+{val:.2f})")
        with c2:
            st.markdown("**Factors decreasing demand**")
            for feat, val in negative:
                st.markdown(f"- {feat.replace('_', ' ')} ({val:.2f})")
    else:
        st.warning("No history for this product.")

    st.caption("SHAP values show each feature's contribution to the model's predicted demand for this "
               "specific product/context, relative to the model's average prediction.")


# ============================================================================
# 21. MAIN APP ENTRY POINT
# ============================================================================
def main():
    st.set_page_config(page_title="AI Dynamic Pricing Engine", page_icon="💹", layout="wide")
    st.markdown(f"<style>{CUSTOM_CSS}</style>", unsafe_allow_html=True)

    with st.spinner("Preparing dataset (first run only — this creates ~20,000 sample transactions)..."):
        build_dataset_if_missing()

    pages = {
        "📊 Dashboard": page_dashboard,
        "🎯 Price Optimizer": page_price_optimizer,
        "📈 Demand Forecasting": page_demand_forecasting,
        "🏷️ Competitor Analysis": page_competitor_analysis,
        "🧪 What-If Simulator": page_what_if_simulator,
        "📊 Product Analytics": page_product_analytics,
        "🚨 Anomaly Detection": page_anomaly_detection,
        "🧠 Model Performance": page_model_performance,
    }

    st.sidebar.title("💹 Dynamic Pricing Engine")
    choice = st.sidebar.radio("Navigate", list(pages.keys()))
    st.sidebar.markdown("---")
    st.sidebar.caption("Data, models and database are auto-created in `dpe_workspace/` next to this file.")

    pages[choice]()


if __name__ == "__main__":
    main()
