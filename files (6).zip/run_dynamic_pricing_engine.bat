@echo off
REM Double-click this file to install dependencies (first time only) and
REM launch the AI-Powered Dynamic Pricing Engine in your browser.
REM Keep this .bat file in the SAME folder as dynamic_pricing_engine.py

cd /d "%~dp0"

echo Checking / installing required packages (first run only, may take a minute)...
python -m pip install --quiet --disable-pip-version-check streamlit pandas numpy scikit-learn xgboost shap plotly joblib

echo.
echo Starting AI-Powered Dynamic Pricing Engine...
echo A browser tab will open automatically at http://localhost:8501
echo (Close this window to stop the app.)
echo.

python -m streamlit run dynamic_pricing_engine.py

pause
